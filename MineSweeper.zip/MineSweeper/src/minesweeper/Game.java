package minesweeper;
import java.util.*;
public class Game {
   Scanner in = new Scanner(System.in);
    public void game(){
        Play p = new Play();
         GRID g = new GRID();
      p.start();
      
     
    }
}
