package minesweeper;
import java.util.*;
public class MineSweeper {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        System.out.println("Welcome, Choose :");
        System.out.println("1-Play");
        System.out.println("2-Exit");
       int x = in.nextInt();
       if(x == 2){
           System.out.println("Thank you for trying our Game, Come Back Again!!");
           return;
       }
        Game G = new Game();
        G.game();      
  }
}