package minesweeper;
public class Data {

    public Data() {
    }
static char [][]Grid = new char[50][50];
static  char[][] grid = new char[50][50];
static int rows,columns,NumMines, TypeOfPlay,Diffeculty,i,j,Done=0,NumOfOpendCell=1,Score1=0,Score2=0,Sizee=27,Move;
static char ChaCell;
static boolean Win1=true,Win2=true,turn=false;
}
