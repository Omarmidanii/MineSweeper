package minesweeper;

import java.util.*;

public class Play {
 
  Scanner in = new Scanner(System.in);
    public void start() {
        GRID g = new GRID();
  Cell c = new Cell();
        System.out.println("You Want To Play in Mode :");
        System.out.println("1-VS Computer");
        System.out.println("2-MultiPlayer");
         System.out.println("3-SinglePlayer");
        Data.TypeOfPlay = in.nextInt();
        System.out.println("Select The Diffeculty : ");
        System.out.println("1-Easy");
        System.out.println("2-Normal");
        System.out.println("3-Hard");
        System.out.println("4-Custom");
        Data.Diffeculty = in.nextInt();
        switch (Data.Diffeculty) {
            case 1:
                Data.columns = 10;
                Data.rows = 10;
                break;
            case 2:
                Data.columns = 16;
                Data.rows = 16;
                break;
            case 3:
                Data.columns = 26;
                Data.rows = 26;
                break;
            default:
                while(Data.Sizee >26){
                System.out.println("Choose the Size of the grid : (Less or equal to 26)");
                Data.Sizee = in.nextInt();
                }
                Data.columns = Data.Sizee;
                Data.rows = Data.Sizee;
                break;
        }
       c.FirstCell();
       if(Data.TypeOfPlay != 3){
           MULTIPLAYER();
       }
       else{
           SINGLEPLAYER();
       }
        for (int i = 0; i < Data.rows; i++) {
            for (int j = 0; j < Data.columns; j++) {
                if (Data.grid[i][j] == 'b') {
                    System.out.print(Data.grid[i][j] + " ");
                } else {
                    System.out.print(Data.Grid[i][j] + " ");
                }
            }
            System.out.println();
        }
    }
    public void FloodFill(int x, int y, boolean t) {
        int[] dx = {0, 0, 1, -1};
        int[] dy = {1, -1, 0, 0};
        for (int i = 0; i < 4; i++) {
            if (x + dx[i] >= 0 && x + dx[i] < Data.rows && y + dy[i] >= 0 && y + dy[i] < Data.columns && Data.grid[x + dx[i]][y + dy[i]] != 'b' && Data.Grid[x + dx[i]][y + dy[i]] == '#') {
                if (Data.grid[x + dx[i]][y + dy[i]] != '0') {
                    Data.Grid[x + dx[i]][y + dy[i]] = Data.grid[x + dx[i]][y + dy[i]];
                } else {
                    Data.Grid[x + dx[i]][y + dy[i]] = Data.grid[x + dx[i]][y + dy[i]];
                    FloodFill(x + dx[i], y + dy[i], t);
                }
                if (!t) {
                    Data.Score1++;
                } else {
                    Data.Score2++;
                }
                Data.NumOfOpendCell++;
            }
        }
    }
    void MULTIPLAYER(){
        GRID g = new GRID();
  Cell c = new Cell();
        Data.Move = 0;
         while (Data.NumOfOpendCell != (int) ((Data.rows) * (Data.columns) - Data.NumMines)) {
            if (Data.turn == true) {
                if (Data.TypeOfPlay == 1) {
                    System.out.println("Computer :");
                    Random rand = new Random();
                    Data.i = rand.nextInt(Data.rows);
                    Data.j = rand.nextInt(Data.columns);
                    if (c.CheckCell() == false) {
                    System.out.println("There Is No Such Cell,Please Try Again!!");
                    continue;
                }
                if (Data.Grid[Data.i][Data.j] != '#' && Data.Grid[Data.i][Data.j] != 'P') {
                    System.out.println("This Is An Opened Cell, Try Again Please!!");
                    continue;
                }
                    if (Data.grid[Data.i][Data.j] != 'b') {
                        Data.Score2 += Data.grid[Data.i][Data.j] - '0';
                        Data.NumOfOpendCell++;
                    }
                    System.out.println("The Computer Has Opened Cell : " + (Data.i+1) + (char) (Data.j + 'A'));
                Data.Grid[Data.i][Data.j] = Data.grid[Data.i][Data.j];
                } else {
                    System.out.println("Second Player :");
                }
            } else {
                System.out.println(" First Player :");
            }
            if (Data.turn == false || Data.TypeOfPlay == 2) {
                System.out.println("Choose : 1-Open Cell      2-Mark Cell");
                Data.Move = in.nextInt();
                System.out.println("Enter The Number Of The Cell : ");
                Data.i = in.nextInt();
                Data.i--;
                System.out.println("Enter The Char Of The Cell : ");
                Data.ChaCell = in.next().charAt(0);
                Data.j = Data.ChaCell;
                Data.j -= 65;
                if (c.CheckCell() == false) {
                    System.out.println("There Is No Such Cell,Please Try Again!!");
                    continue;
                }
                if (Data.Grid[Data.i][Data.j] != '#' && Data.Grid[Data.i][Data.j] != 'P') {
                    System.out.println("This Is An Opened Cell, Try Again Please!!");
                    continue;
                }
                if (Data.Grid[Data.i][Data.j] == 'P' && Data.Move == 2) {
                    System.out.println("This Is A Marked Cell, Try Again Please!!");
                    continue;
                }
                Data.Grid[Data.i][Data.j] = Data.grid[Data.i][Data.j];
                if (Data.Move == 1 && Data.grid[Data.i][Data.j] != 'b') {
                    if (Data.turn == false) {
                        Data.Score1 += Data.grid[Data.i][Data.j] - '0';
                    } else {
                        Data.Score2 += Data.grid[Data.i][Data.j] - '0';
                    }
                    Data.NumOfOpendCell++;
                } else {
                    Data.Grid[Data.i][Data.j] = 'P';
                    if (Data.grid[Data.i][Data.j] == 'b') {
                        if (Data.turn == false) {
                            Data.Score1 += 5;
                        } else {
                            Data.Score2 += 5;
                        }
                    } else {
                        if (Data.turn == true) {
                            Data.Score2--;
                        } else {
                            Data.Score1--;
                        }
                    }
                }
            }
            if (Data.grid[Data.i][Data.j] == 'b' && Data.Move != 2) {
                if (Data.turn == false) {
                    Data.Win1 = false;
                    Data.Score1 -= 250;
                } else {
                    Data.Win2 = false;
                    Data.Score2 -= 250;
                }
                break;
            }
            if (Data.grid[Data.i][Data.j] == '0' && Data.Move != 2) {
                FloodFill(Data.i, Data.j, Data.turn);
            }
            g.GeneratGrid();
            Data.turn = !(Data.turn);
            Data.Move= 0;
        }
            if (Data.Win1 == false || Data.Score2 > Data.Score1) {
            System.out.println("Player 2 Has Won");
        } else if (Data.Win2 == false || Data.Score1 > Data.Score2) {
            System.out.println("Player 1 Has Won");
        } else {
            System.out.println("Tie");
        }
        System.out.println("Player 1 Score :" + Data.Score1);
        System.out.println("Player 2 Score :" + Data.Score2);
    }
    void SINGLEPLAYER(){
        GRID g = new GRID();
        Cell c = new Cell();
        while(Data.NumOfOpendCell < (int)(((Data.rows)*(Data.columns)) - Data.NumMines)){
            System.out.println("CHOOSE : 1-Open Cell\t 2-Mark Cell");
                Data.Move = in.nextInt();
            System.out.println("Enter The Number Of The Cell : ");
            Data.i = in.nextInt();
            Data.i--;
            System.out.println("Enter The Char Of The Cell : ");
            Data.ChaCell = in.next().charAt(0);
            Data.j = Data.ChaCell;
            Data.j -= 65;
            if (c.CheckCell() == false) {
                    System.out.println("There Is No Such Cell,Please Try Again!!");
                    continue;
                }
                if (Data.Grid[Data.i][Data.j] != '#' && Data.Grid[Data.i][Data.j] != 'P') {
                    System.out.println("This Is An Opened Cell, Try Again Please!!");
                    continue;
                }
                if (Data.Grid[Data.i][Data.j] == 'P' && Data.Move == 2) {
                    System.out.println("This Is A Marked Cell, Try Again Please!!");
                    continue;
                }
                if(Data.Move == 1){
                    Data.Grid[Data.i][Data.j] = Data.grid[Data.i][Data.j];
                    Data.NumOfOpendCell++;
                }
                else{
                    Data.Grid[Data.i][Data.j] = 'P';
                }
                if(Data.grid[Data.i][Data.j] == 'b' && Data.Move != 2){
                    Data.Win1 =false;
                }
                if(Data.grid[Data.i][Data.j] == '0' && Data.Move != 2)FloodFill(Data.i,Data.j,false);
                Data.Move = 0;
                g.GeneratGrid();
        }
        if(!Data.Win1){
            System.out.println("GAME OVERRRR, DON'T  COME BACK!!");
        }
        else{
            System.out.println("WOW, YOU WON THE GAME!!");
        }
    }
}
