package minesweeper;
import java.util.*;
public class GRID {
    public void initializeGrid() {
        for (int i = 0; i < Data.rows; i++) {
            for (int j = 0; j < Data.columns; j++) {
                Data.Grid[i][j] = '#';
            }
        }
    }
    public void GeneratGrid() {
        for (int i = 0; i < Data.columns + 2; i++) {
            System.out.print("__");
        }
        System.out.println();
        System.out.print("   ");
        for (int i = 0; i < Data.columns; i++) {
            System.out.print((char) (i + 'A') + " ");
        }
        System.out.println();
        for (int i = 0; i < Data.rows; i++) {
            System.out.print(i + 1);
            if (i < 9)  System.out.print("  ");
            else  System.out.print(" ");
            for (int j = 0; j < Data.columns; j++) {
                System.out.print(Data.Grid[i][j] + " ");
            }
            System.out.println();
        }
         for (int i = 0; i < Data.columns + 2; i++) {
            System.out.print("__");
        }
        System.out.println();
    }

    public void GenerateMines() {
        int count = 0;
        Random rand = new Random();
        while (count < Data.NumMines) {
            int x = rand.nextInt(Data.rows);
            int y = rand.nextInt(Data.columns);
            if (Data.grid[x][y] != 'b' && x != Data.i && y != Data.j) {
                Data.grid[x][y] = 'b';
                count++;
            }
        }
        int[] dx = {0,0,1,-1,1,1,-1,-1};
        int[] dy = {1,-1,0,0,1,-1,-1,1};
        for (int i = 0; i < Data.rows; i++) {
            for (int j = 0; j < Data.columns; j++) {
                if (Data.grid[i][j] != 'b') {
                    int cnt = 0;
                    for (int k = 0; k < 8; k++) {
                        if (i + dx[k] < Data.rows && i + dx[k] >= 0 && j + dy[k] < Data.columns && j + dy[k] >= 0 && Data.grid[i + dx[k]][j + dy[k]] == 'b')     cnt++;
                    }
                    char s = (char) (cnt + '0');  Data.grid[i][j] = s;
                }
            }
        }
    }
}
