
package minesweeper;

import javax.swing.*;
import java.awt.*;
import java.util.*;
public class gui  extends JFrame{
    public gui(){
        this.setTitle("MineSweeper");
        this.setSize(1286,829);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setVisible(true);
        this.setResizable(false);
    }
}
