package minesweeper;
import java.util.*;
public class Cell {
    Scanner in = new Scanner(System.in);
    GRID g  = new GRID();
    Play p = new Play();
 public boolean CheckCell(){
     return !(Data.i < 0 || Data.j < 0 || Data.i >= Data.rows || Data.j >= Data.columns );
 
    }
 public void FirstCell(){
      g.initializeGrid();
        g.GeneratGrid();
        Data.NumMines = (int) ((Data.rows) * (Data.columns) * (0.2));
        if(Data.TypeOfPlay != 3)
        System.out.println("First Player :");
        System.out.println("Enter The Number Of The Cell You Want To Open: ");
        Data.i = in.nextInt();
        Data.i--;
        System.out.println("Enter The Char Of The Cell You Want To Open: ");
        Data.ChaCell = in.next().charAt(0);
        Data.j = Data.ChaCell;
        Data.j -= 65;
        Data.Done = 1;
        CheckCell();
        g.GenerateMines();
        if (Data.grid[Data.i][Data.j] == '0') {
            p.FloodFill(Data.i, Data.j, false);
        }
        Data.Grid[Data.i][Data.j] = Data.grid[Data.i][Data.j];
        Data.Score1 += Data.grid[Data.i][Data.j] - '0';
        g.GeneratGrid();
        Data.turn = true;
 }

   
}
